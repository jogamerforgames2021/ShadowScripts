/*!-----------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Version: 0.48.0(0037b13fb5d186fdf1e7df51a9416a2de2b8c670)
 * Released under the MIT license
 * https://github.com/microsoft/vscode/blob/main/LICENSE.txt
 *-----------------------------------------------------------*/

/*---------------------------------------------------------
 * Copyright (c) Microsoft Corporation. All rights reserved.
 *--------------------------------------------------------*/
define("vs/base/common/worker/simpleWorker.nls", {
	"vs/base/common/platform": [
		"_"
	],
	"vs/editor/common/languages": [
		"array",
		"boolean",
		"class",
		"constant",
		"constructor",
		"enumeration",
		"enumeration member",
		"event",
		"field",
		"file",
		"function",
		"interface",
		"key",
		"method",
		"module",
		"namespace",
		"null",
		"number",
		"object",
		"operator",
		"package",
		"property",
		"string",
		"struct",
		"type parameter",
		"variable",
		"{0} ({1})"
	]
});